﻿using PasechnikovaPR33p5WPF.Views;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PasechnikovaPR33p5WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow :Window
    {
        private Page [ ] pages;

        public MainWindow ()
        {
            InitializeComponent( );
            pages = new Page [ ]
            {
                new ItemsControlPage(ponies)
            };
            pagesComboBox.ItemsSource = pages;
            pagesComboBox.DisplayMemberPath = "Title";
        }
        private void SelectWindow (object sender, SelectionChangedEventArgs e)
        {
            Page? page = pagesComboBox.SelectedItem as Page;
            mainFrame.Navigate(page);
        }
        private List<Pony> ponies = new List<Pony>
        {
            new Pony
            {
                Name = "Рарити",
                Tip = "Единорог",
                Description = "Единорог светло-серого цвета, с гривой пурпурно-синего цвета. Её знак отличия — три ромбовидных бриллианта.",
                PhotoUrl = "https://static.wikia.nocookie.net/mlp/images/a/a4/Rarity_ID_card.png/revision/latest?cb=20170928202010&path-prefix=ru",
                BgColor = "#d8bfd8"

            },
            new Pony
            {
                Name = "Пинки Пай",
                Tip = "Земная пони",
                Description = "Ярко-розовая земная пони с тёмно-розовой гривой. Её знак отличия — три воздушных шарика: один жёлтый и два голубых.",
                PhotoUrl = "https://static.wikia.nocookie.net/mlp/images/b/b2/Pinkie_Pie_ID_S4E11.png",
                BgColor = "#ffd1dc"

            },
            new Pony
            {
                Name = "Эпплджек",
                Tip = "Земная пони",
                Description = "Ораневая земная пони с блондинестой гривой. Ее знак отличия - три красных яблока",
                PhotoUrl = "https://static.wikia.nocookie.net/mlp/images/d/d8/Applejack_S01E13_cropped.png",
                BgColor = "#e79a88"

            },
            new Pony
            {
                Name = "Радуга",
                Tip = "Пегас",
                Description = "Небесно-голубая пони-пегас с радужной гривой и хвостом. Её знак отличия — радуга",
                PhotoUrl = "https://static.wikia.nocookie.net/mlp/images/4/4b/Rainbow_Dash_Wonderbolt_fantasy_cropped_S1E3.png",
                BgColor = "#8bd6e4"

            },
            new Pony
            {
                Name = "Искорка",
                Tip = "Аликорн",
                Description = "Пони-единорог сиреневого цвета, с гривой тёмно-синего цвета и розово-фиолетовыми прядями. Её знак отличия — розовая шестиконечная звезда в окружении пяти маленьких белых звёзд.",
                PhotoUrl = "https://static.wikia.nocookie.net/mlp/images/b/bc/Princess_Twilight_Sparkle_ID_S4E26.png",
                BgColor = "#b495da"

            },
            new Pony
            {
                Name = "Флотершай",
                Tip = "Единорог",
                Description = "Пегас, ее кожа имеет нежный желтый оттенок, а волосы розового цвета. Ее знак отличия - три розовые бабочки",
                PhotoUrl = "https://static.wikia.nocookie.net/mlp/images/e/ea/FluttershyS1E23.png/revision/latest?cb=20171005212035&path-prefix=ru",
                BgColor = "#f5f5dc"

            }
        };
    }
}