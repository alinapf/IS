﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PasechnikovaPR33p5WPF.Views
{
    /// <summary>
    /// Логика взаимодействия для ItemsControlPage.xaml
    /// </summary>
    public partial class ItemsControlPage :Page
    {
        private readonly List<Pony> ponies;

        public ItemsControlPage (List<Pony> ponies)
        {
            InitializeComponent( );
            this.ponies = ponies;
            poniesItemsControl.ItemsSource = ponies;
        }
    }
}
