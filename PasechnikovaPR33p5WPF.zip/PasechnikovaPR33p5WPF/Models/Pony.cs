﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace PasechnikovaPR33p5WPF
{
    public class Pony
    {
        public string Name { get; set; } = string.Empty;
        public string Tip { get; set; } = string.Empty;
        public string? Description { get; set; }
        public string? PhotoUrl { get; set; }
        public string BgColor { get; set; } = string.Empty;
    }
}
