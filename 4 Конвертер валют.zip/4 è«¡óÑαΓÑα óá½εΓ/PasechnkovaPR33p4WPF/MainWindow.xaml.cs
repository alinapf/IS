﻿using PasechnkovaPR33p4WPF.Model;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PasechnkovaPR33p4WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow :Window
    {
        private List<Valute> valutes;
        public MainWindow ()
        {
            InitializeComponent( );
            string xmlText;
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            try
            {
                HttpClient client = new HttpClient( );
                var respose =
                    client.GetAsync("https://www.cbr.ru/scripts/XML_daily.asp")
                        .GetAwaiter( ).GetResult( );
                xmlText = respose.Content.ReadAsStringAsync( ).GetAwaiter( ).GetResult( );
                StreamWriter sw = new StreamWriter("data/valutes.xml");
                sw.Write(xmlText);
                sw.Close( );
            }
            catch
            {
                xmlText = File.ReadAllText("data/valutes.xml");
            }



            valutes = Data.ValuteLoader.LoadValutes(xmlText);
            valutes.Insert(0, new Valute { Name = "Российский Рубль", Value = 1, Nominal = 1, CharCode = "RUB" });
            FromComboBox.ItemsSource = valutes;
            ToComboBox.ItemsSource = valutes;
        }
        private void FilterText (object sender, TextCompositionEventArgs e)
        {
            if (!int.TryParse(e.Text, out int x))
            {
                e.Handled = true;
            }
        }


        private void Calculate (object sender, TextChangedEventArgs e)
        {
            Valute? inValute = FromComboBox.SelectedItem as Valute;
            Valute? outValute = ToComboBox.SelectedItem as Valute;
            if (inValute == null || outValute == null)
            {
                return;
            }

            int value;
            bool succ = int.TryParse(InputBox.Text, out value);
            if (!succ) return;

            double rubles = value * inValute.Value;
            double result = rubles / outValute.Value;

            OutputBox.Text = result.ToString( );
        }
    }
}