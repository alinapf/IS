﻿using PasechnkovaPR33p4WPF.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PasechnkovaPR33p4WPF.Data
{
    public static class ValuteLoader
    {
        public static List<Valute> LoadValutes (string XMLText)
        {
            XDocument doc = XDocument.Parse(XMLText);
            List <Valute> nodes = new List<Valute>( );
            foreach (XElement node in doc.Element("ValCurs").Elements("Valute"))
            {
                var valute = new Valute
                { 
                    Name = node.Element("Name").Value,
                    Value = Convert.ToDouble(node.Element("Value").Value),
                    CharCode = node.Element("CharCode").Value,
                    Nominal = Convert.ToInt32(node.Element("Nominal").Value)
                };
                nodes.Add(valute);

            }
            return nodes;
        }
    }
}
