﻿using System.Xml;
using System.Xml.Linq;





//
XDocument doc = XDocument.Load("valutes.xml");



Console.WriteLine("Введите валюту для поиска:");
string str = Console.ReadLine( );

var nodes = doc.Element("ValCurs")
    .Elements("Valute");

foreach (XElement node in doc.Element("ValCurs").Elements("Valute"))
{
    if (Convert.ToString(node.Element("Name").Value) == str)
    {
        Console.WriteLine(node.Element("Value").Value);
    }
    
}
//




Console.ReadKey( );
